"""Top-level package for pyJM."""

__author__ = """Jamie Massey"""
__email__ = 'jamie435@hotmail.co.uk'
__version__ = '0.4.0'
