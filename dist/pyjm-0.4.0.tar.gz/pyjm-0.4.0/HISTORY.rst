=======
History
=======

0.4.0 (2024-03-12)
------------------

* mumax altered to use Stoner.formats.OVFFile


0.3.0 (2024-03-12)
------------------

* Installation issues addressed

0.2.0 (2024-03-12)
------------------

* Unused/unfinished modules removed 


0.1.0 (2024-03-12)
------------------

* First release on PyPI.
