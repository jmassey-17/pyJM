=====
Usage
=====

To use pyJM2 in a project::

    import pyJM2
