"""Package to look at and analyse magnetic microscopy data."""

__author__ = """Jamie Massey"""
__email__ = 'jamie435@hotmail.co.uk'
__version__ = '0.3.0'
